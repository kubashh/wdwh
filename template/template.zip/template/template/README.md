# WDWH app usage

```bash
bun update      # install and update deps
bun dev         # development
bun run build   # build project
```
