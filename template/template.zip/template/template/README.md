# Create wdwh (web development without html) app in one command

## Usage

```bash
bun create wdwh-app@latest [path] # "." for current directory
```

## Related

[wdwh](https://npmjs.com/package/wdwh) - web development without html
