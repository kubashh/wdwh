export default function App() {
  return (
    <>
      <main>Hello world!</main>
    </>
  )
}
